self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d77ff63f65331ce3a9ab1df493fcd911",
    "url": "/index.html"
  },
  {
    "revision": "0f90a6af2644a406c8dc",
    "url": "/static/css/2.05ffced1.chunk.css"
  },
  {
    "revision": "97a3eb0ca107839d173f",
    "url": "/static/css/main.a2b822fe.chunk.css"
  },
  {
    "revision": "0f90a6af2644a406c8dc",
    "url": "/static/js/2.edacb0a6.chunk.js"
  },
  {
    "revision": "2ca78df4e200ab631a9acbb7a85ee5b8",
    "url": "/static/js/2.edacb0a6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "97a3eb0ca107839d173f",
    "url": "/static/js/main.8b3a461f.chunk.js"
  },
  {
    "revision": "9f46e840e4c9ad567e30",
    "url": "/static/js/runtime-main.3918aed9.js"
  },
  {
    "revision": "2e036e3efaeb4f9423c4039c5127f224",
    "url": "/static/media/logo.2e036e3e.png"
  }
]);